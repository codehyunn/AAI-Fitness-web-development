from flask import Flask, render_template
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.service import Service
from bs4 import BeautifulSoup
import pandas as pd
import time
import random
 
app = Flask(__name__)

service = Service(ChromeDriverManager().install())

@app.route('/')
def crawling():
    keyword = input('검색어를 입력하시오: ')
    SEARCH_KEYWORD = keyword.replace(' ', '+')
    driver = webdriver.Chrome(service=service)
    URL = "https://www.youtube.com/results?search_query=" + SEARCH_KEYWORD
    driver.get(URL)
    time.sleep(3)

    html_source = driver.page_source
    soup_source = BeautifulSoup(html_source, 'html.parser')

    content_total = soup_source.find_all(class_ = 'yt-simple-endpoint style-scope ytd-video-renderer')
    content_total_title = list(map(lambda data: data.get_text().replace("\n", ""), content_total))
    content_total_link = list(map(lambda data: "https://youtube.com" + data["href"], content_total))
    content_total_dict = {'title' : content_total_title, 'link': content_total_link}

    df = pd.DataFrame(content_total_dict)
    df.to_csv("/Users/seoyoung/Desktop/mediapipe_web_final/data/content_total.csv", encoding='utf-8-sig')
    file = '/Users/seoyoung/Desktop/mediapipe_web_final/data/content_total.csv' # 경로 수정
    df = pd.read_csv(file)
    result = df.sample(n = 6, replace = False)
    print(result[['title','link']])
    return render_template("./youtube-recommend-new/youtube.html", variable = SEARCH_KEYWORD)
 
if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, threaded=True)
